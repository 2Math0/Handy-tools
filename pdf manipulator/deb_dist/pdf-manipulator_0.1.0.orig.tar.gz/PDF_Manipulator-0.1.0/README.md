### This GUI app is made by python, PySimpleGUI package
Its main function to edit PDFs

for now it has deleting pages function

to install 
$ dpkg -i package